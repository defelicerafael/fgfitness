function ProcessedElement(element, position) {
	this.elem = element;
	this.pos = position;
}